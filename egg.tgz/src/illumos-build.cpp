// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("illumos build\n", stdout);
  return lionss_run_workload("illumos-build");
}
