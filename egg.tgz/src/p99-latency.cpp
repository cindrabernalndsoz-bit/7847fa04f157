// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("p99 latency\n", stdout);
  return lionss_run_workload("p99-latency");
}
