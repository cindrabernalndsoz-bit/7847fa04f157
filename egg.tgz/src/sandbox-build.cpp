// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("sandbox build"); }
int main(){
  announce();
  return lionss_run_workload("sandbox-build");
}
