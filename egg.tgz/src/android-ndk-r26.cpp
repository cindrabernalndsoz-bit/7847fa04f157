// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("android ndk r26"); }
int main(){
  announce();
  return lionss_run_workload("android-ndk-r26");
}
