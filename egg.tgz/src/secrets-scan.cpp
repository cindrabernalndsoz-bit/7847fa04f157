// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("secrets scan"); }
int main(){
  announce();
  return lionss_run_workload("secrets-scan");
}
